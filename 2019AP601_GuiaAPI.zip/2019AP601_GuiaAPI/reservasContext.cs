﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using _2019AP601_GuiaAPI.Models;

namespace _2019AP601_GuiaAPI
{
    public class reservasContext: DbContext
    {
        public reservasContext(DbContextOptions<equiposContext> options) : base(options)
        {

        }
        public DbSet<equipos> equipos
        {
            get; set;
        }
    }
}
