﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using _2019AP601_GuiaAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace _2019AP601_GuiaAPI.Controllers
{
    [ApiController]
    public class tipo_equipocontroller : ControllerBase
    {
        private readonly tipo_equipoContext _contexto;
        public tipo_equipocontroller(tipo_equipoContext miContexto)
        {
            this._contexto = miContexto;
        }
        [HttpGet]
        [Route("api/tipo_equipo")]
        public IActionResult Get()
        {
            IEnumerable<tipo_equipo> tipoequipoList = from e in _contexto.tipo_equipo
                                                      select e;
            if (tipoequipoList.Count() < 0)
            {
                return Ok(tipoequipoList);
            }
            return NotFound();

        }

        [HttpGet]
        [Route("api/tipo_equipo/{id}")]
        public IActionResult getbyId(int id)
        {
            tipo_equipo unTipo = (from e in _contexto.tipo_equipo
                                  where e.id_tipo_equipo == id
                                  select e).FirstOrDefault();
            if (unTipo != null)
            {
                return Ok(unTipo);
            }
            return NotFound();
        }

        [HttpPost]
        [Route("api/tipo_equipo")]
        public IActionResult guardarTipo([FromBody] tipo_equipo tipoNuevo)
        {
            try
            {
                IEnumerable<tipo_equipo> tipoExiste = from e in _contexto.tipo_equipo
                                                      where e.estado == tipoNuevo.estado
                                                      select e;
                if (tipoExiste.Count() == 0)
                {
                    _contexto.tipo_equipo.Add(tipoNuevo);
                    _contexto.SaveChanges();
                    return Ok(tipoNuevo);
                }
                return Ok(tipoExiste);
            }
            catch (System.Exception)
            {
                return BadRequest();

            }
        }

        [HttpPut]
        [Route("api/tipo_equipo")]
        public IActionResult updateTipo([FromBody] tipo_equipo tipoAModificar)
        {
            tipo_equipo tipoExiste = (from e in _contexto.tipo_equipo
                                      where e.id_tipo_equipo == tipoAModificar.id_tipo_equipo
                                      select e).FirstOrDefault();
            if (tipoExiste is null)
            {
                return NotFound();
            }
            tipoExiste.descripcion = tipoAModificar.descripcion;
            tipoExiste.estado = tipoAModificar.estado;

            _contexto.Entry(tipoExiste).State = EntityState.Modified;
            _contexto.SaveChanges();
            return Ok(tipoExiste);

        }
    }
}
