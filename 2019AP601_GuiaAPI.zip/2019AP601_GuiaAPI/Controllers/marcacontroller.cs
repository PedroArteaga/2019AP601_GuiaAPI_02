﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using _2019AP601_GuiaAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace _2019AP601_GuiaAPI.Controllers
{
    [ApiController]
    public class marcacontroller : ControllerBase
    {
        private readonly marcaContext _contexto;
        public marcacontroller(marcaContext miContexto)
        {
            this._contexto = miContexto;
        }
        [HttpGet]
        [Route("api/marcas")]
        public IActionResult Get()
        {
            IEnumerable<Marca> marcaList = from e in _contexto.marcas
                                           select e;
            if (marcaList.Count() < 0)
            {
                return Ok(marcaList);
            }
            return NotFound();

        }

        [HttpGet]
        [Route("api/marcas/{id}")]
        public IActionResult getbyId(int id)
        {
            Marca unaMarca = (from e in _contexto.marcas
                              where e.id_marcas == id
                              select e).FirstOrDefault();
            if (unaMarca != null)
            {
                return Ok(unaMarca);
            }
            return NotFound();
        }

        [HttpGet]
        [Route("api/marcas/buscarnombre/{buscarNombre}")]
        public IActionResult obtenerNombre(string buscarNombre)
        {
            IEnumerable<Marca> marcaPorNombre = from e in _contexto.marcas
                                                where e.nombre_marca.Contains(buscarNombre)
                                                select e;
            if (marcaPorNombre.Count() > 0)
            {
                return Ok(marcaPorNombre);
            }
            return NotFound();
        }

        [HttpPost]
        [Route("api/marcas")]
        public IActionResult GuardarMarca([FromBody] Marca marcaNueva)
        {
            try
            {
                IEnumerable<Marca> marcaExiste = from e in _contexto.marcas
                                                 where e.nombre_marca == marcaNueva.nombre_marca
                                                 select e;
                if (marcaExiste.Count() == 0)
                {
                    _contexto.marcas.Add(marcaNueva);
                    _contexto.SaveChanges();
                    return Ok(marcaNueva);
                }
                return Ok(marcaExiste);
            }
            catch (System.Exception)
            {
                return BadRequest();

            }
        }

        [HttpPut]
        [Route("api/marcas")]
        public IActionResult ModificarMarca([FromBody] Marca marcaAModificar)
        {
            Marca marcaExiste = (from e in _contexto.marcas
                                 where e.id_marcas == marcaAModificar.id_marcas
                                 select e).FirstOrDefault();
            if (marcaExiste is null)
            {
                return NotFound();
            }
            marcaExiste.nombre_marca = marcaAModificar.nombre_marca;
            marcaExiste.estados = marcaAModificar.estados;

            _contexto.Entry(marcaExiste).State = EntityState.Modified;
            _contexto.SaveChanges();
            return Ok(marcaExiste);

        }

    }
}
